from flask import Flask, request, jsonify
from flask_cors import CORS
import sqlite3
from datetime import datetime, timedelta

app = Flask(__name__)
CORS(app)

DB = 'db.sqlite3'

def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoiceNumber TEXT UNIQUE,
        date TEXT,
        dueDate TEXT,
        status TEXT,
        clientName TEXT,
        clientFirstName TEXT,
        clientCompany TEXT,
        clientAddress TEXT,
        clientPhone TEXT,
        clientEmail TEXT,
        clientNina TEXT,
        items TEXT, -- JSON
        subtotalHT REAL,
        totalVAT REAL,
        totalTTC REAL,
        discount REAL,
        deposit REAL,
        balance REAL,
        paymentTerms TEXT,
        notes TEXT
    )
    ''')
    conn.commit()
    conn.close()

@app.before_first_request
def startup():
    init_db()

def get_next_invoice_number():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    year = datetime.now().year
    c.execute("SELECT COUNT(*) FROM invoices WHERE invoiceNumber LIKE ?", (f"FAC-{year}-%",))
    count = c.fetchone()[0] + 1
    conn.close()
    return f"FAC-{year}-{str(count).zfill(3)}"

@app.route('/api/invoices', methods=['GET'])
def list_invoices():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM invoices")
    rows = c.fetchall()
    columns = [desc[0] for desc in c.description]
    data = [dict(zip(columns, row)) for row in rows]
    conn.close()
    return jsonify(data)

@app.route('/api/invoices', methods=['POST'])
def create_invoice():
    data = request.get_json()
    invoiceNumber = get_next_invoice_number()
    date = data.get('date', datetime.now().strftime('%Y-%m-%d'))
    dueDate = data.get('dueDate', (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d'))
    status = data.get('status', 'draft')
    client = data.get('client', {})
    items = data.get('items', [])
    import json
    items_json = json.dumps(items)
    subtotalHT = data.get('totals', {}).get('subtotalHT', 0)
    totalVAT = data.get('totals', {}).get('totalVAT', 0)
    totalTTC = data.get('totals', {}).get('totalTTC', 0)
    discount = data.get('totals', {}).get('discount', 0)
    deposit = data.get('totals', {}).get('deposit', 0)
    balance = data.get('totals', {}).get('balance', 0)
    paymentTerms = data.get('paymentTerms', '')
    notes = data.get('notes', '')

    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''
    INSERT INTO invoices (
        invoiceNumber, date, dueDate, status,
        clientName, clientFirstName, clientCompany, clientAddress,
        clientPhone, clientEmail, clientNina, items,
        subtotalHT, totalVAT, totalTTC,
        discount, deposit, balance,
        paymentTerms, notes
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        invoiceNumber, date, dueDate, status,
        client.get('name', ''), client.get('firstName', ''), client.get('company', ''),
        client.get('address', ''), client.get('phone', ''), client.get('email', ''),
        client.get('nina', ''), items_json, subtotalHT, totalVAT, totalTTC,
        discount, deposit, balance, paymentTerms, notes
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True, 'invoiceNumber': invoiceNumber})

@app.route('/api/invoices/<invoiceNumber>', methods=['GET'])
def get_invoice(invoiceNumber):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("SELECT * FROM invoices WHERE invoiceNumber=?", (invoiceNumber,))
    row = c.fetchone()
    columns = [desc[0] for desc in c.description]
    conn.close()
    if not row:
        return jsonify({'error': 'Not found'}), 404
    import json
    data = dict(zip(columns, row))
    data['items'] = json.loads(data['items'])
    return jsonify(data)

@app.route('/api/invoices/<invoiceNumber>', methods=['PUT'])
def update_invoice(invoiceNumber):
    data = request.get_json()
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    import json
    items_json = json.dumps(data.get('items', []))
    c.execute('''
    UPDATE invoices SET
        date=?, dueDate=?, status=?,
        clientName=?, clientFirstName=?, clientCompany=?, clientAddress=?,
        clientPhone=?, clientEmail=?, clientNina=?, items=?,
        subtotalHT=?, totalVAT=?, totalTTC=?,
        discount=?, deposit=?, balance=?,
        paymentTerms=?, notes=?
    WHERE invoiceNumber=?
    ''', (
        data.get('date', ''), data.get('dueDate', ''), data.get('status', ''),
        data.get('client', {}).get('name', ''), data.get('client', {}).get('firstName', ''),
        data.get('client', {}).get('company', ''), data.get('client', {}).get('address', ''),
        data.get('client', {}).get('phone', ''), data.get('client', {}).get('email', ''),
        data.get('client', {}).get('nina', ''), items_json,
        data.get('totals', {}).get('subtotalHT', 0), data.get('totals', {}).get('totalVAT', 0),
        data.get('totals', {}).get('totalTTC', 0), data.get('totals', {}).get('discount', 0),
        data.get('totals', {}).get('deposit', 0), data.get('totals', {}).get('balance', 0),
        data.get('paymentTerms', ''), data.get('notes', ''), invoiceNumber
    ))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

@app.route('/api/invoices/<invoiceNumber>', methods=['DELETE'])
def delete_invoice(invoiceNumber):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute("DELETE FROM invoices WHERE invoiceNumber=?", (invoiceNumber,))
    conn.commit()
    conn.close()
    return jsonify({'success': True})

if __name__ == "__main__":
    app.run(debug=True)