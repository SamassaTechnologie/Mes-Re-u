import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Invoices() {
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    // Remplacez ci-dessous par l'URL de votre API Flask hébergée
    fetch("https://VOTRE-API-FLASK-URL/api/invoices")
      .then(res => res.json())
      .then(data => setInvoices(data));
  }, []);

  return (
    <div>
      <h2 className="text-xl font-bold mb-4 text-blue-700">Factures</h2>
      <Link to="/create-invoice" className="mb-4 inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Nouvelle Facture</Link>
      <div className="mt-6">
        <table className="min-w-full bg-white rounded shadow">
          <thead>
            <tr className="bg-gray-100">
              <th className="py-2 px-3">Numéro</th>
              <th className="py-2 px-3">Client</th>
              <th className="py-2 px-3">Date</th>
              <th className="py-2 px-3">Montant TTC</th>
              <th className="py-2 px-3">Statut</th>
            </tr>
          </thead>
          <tbody>
            {invoices.map(inv => (
              <tr key={inv.invoiceNumber}>
                <td className="py-2 px-3">{inv.invoiceNumber}</td>
                <td className="py-2 px-3">{inv.clientName} {inv.clientFirstName}</td>
                <td className="py-2 px-3">{inv.date}</td>
                <td className="py-2 px-3">{inv.totalTTC} FCFA</td>
                <td className="py-2 px-3">
                  <span className={`px-2 py-1 rounded text-white ${inv.status === "payée" ? "bg-green-600" : inv.status === "envoyée" ? "bg-blue-600" : inv.status === "en retard" ? "bg-red-600" : "bg-yellow-600"}`}>
                    {inv.status}
                  </span>
                </td>
              </tr>
            ))}
            {!invoices.length && (
              <tr>
                <td colSpan={5} className="py-3 text-center text-gray-400">Aucune facture</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}