import React from "react";
import logo from "/logo.png";

function formatMoney(val) {
  return `${val.toLocaleString()} FCFA`;
}

export default function InvoicePreview({ client, items, date, dueDate, status, paymentTerms, notes, totals }) {
  return (
    <div className="bg-white p-6 rounded shadow">
      <div className="flex items-center gap-2 mb-4">
        <img src={logo} alt="Logo Samassa" className="h-8 w-8" />
        <div className="font-bold text-lg text-blue-700">Facture Professionnelle</div>
      </div>
      <div className="mb-2"><b>Date :</b> {date}</div>
      <div className="mb-2"><b>Échéance :</b> {dueDate}</div>
      <div className="mb-2"><b>Statut :</b> {status}</div>
      <hr className="my-2"/>
      <div className="mb-2"><b>Client :</b> {client.name} {client.firstName}</div>
      <div className="mb-2"><b>Entreprise :</b> {client.company}</div>
      <div className="mb-2"><b>Adresse :</b> {client.address}</div>
      <div className="mb-2"><b>Téléphone :</b> {client.phone}</div>
      <div className="mb-2"><b>Email :</b> {client.email}</div>
      <div className="mb-2"><b>NINA :</b> {client.nina}</div>
      <hr className="my-2"/>
      <table className="min-w-full text-sm">
        <thead>
          <tr>
            <th>Description</th>
            <th>Qté</th>
            <th>PU HT</th>
            <th>TVA</th>
            <th>Total TTC</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item, idx) => {
            const totalHT = item.quantity * item.unitPrice;
            const totalVAT = item.vatRate === 0 ? 0 : (totalHT * item.vatRate / 100);
            const totalTTC = totalHT + totalVAT;
            return (
              <tr key={idx}>
                <td>{item.description}</td>
                <td>{item.quantity}</td>
                <td>{formatMoney(item.unitPrice)}</td>
                <td>{item.vatRate}%</td>
                <td>{formatMoney(totalTTC)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <hr className="my-2"/>
      <div><b>Sous-total HT :</b> {formatMoney(totals.subtotalHT)}</div>
      <div><b>Total TVA :</b> {formatMoney(totals.totalVAT)}</div>
      <div><b>Total TTC :</b> {formatMoney(totals.totalTTC)}</div>
      <div><b>Remise :</b> {formatMoney(totals.discount)}</div>
      <div><b>Acompte versé :</b> {formatMoney(totals.deposit)}</div>
      <div><b>Solde à payer :</b> {formatMoney(totals.balance)}</div>
      <hr className="my-2"/>
      <div><b>Conditions :</b> {paymentTerms}</div>
      <div className="mt-2 text-sm text-gray-600">{notes}</div>
      <hr className="my-2"/>
      <div className="text-xs text-gray-400">SAMASSA TECHNOLOGIE | Grand Marché de Kayes | 77291931 / 62970630 | boussesamassa10@gmail.com</div>
    </div>
  );
}