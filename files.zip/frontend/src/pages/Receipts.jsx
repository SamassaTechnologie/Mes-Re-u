import React from "react";
import { Link } from "react-router-dom";

export default function Receipts() {
  return (
    <div>
      <h2 className="text-xl font-bold mb-4 text-blue-700">Générateur de Reçus</h2>
      <Link to="/create-receipt" className="mb-4 inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Nouveau Reçu</Link>
      <div className="mt-2 text-gray-400">Historique à venir…</div>
    </div>
  );
}