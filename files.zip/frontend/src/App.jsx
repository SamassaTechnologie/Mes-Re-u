import React from "react";
import Navbar from "./components/Navbar";
import Dashboard from "./components/Dashboard";
import ReceiptGenerator from "./components/ReceiptGenerator";
import InvoiceGenerator from "./components/InvoiceGenerator";
import Invoices from "./pages/Invoices";
import Receipts from "./pages/Receipts";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <BrowserRouter>
      <div className="bg-gray-50 min-h-screen">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/receipts" element={<Receipts />} />
            <Route path="/invoices" element={<Invoices />} />
            <Route path="/create-receipt" element={<ReceiptGenerator />} />
            <Route path="/create-invoice" element={<InvoiceGenerator />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;