import React, { useState } from "react";
import InvoicePreview from "./InvoicePreview";

const emptyItem = { description: "", quantity: 1, unitPrice: 0, vatRate: 18 };

function calculateTotals(items, discount = 0, deposit = 0) {
  let subtotalHT = 0, totalVAT = 0, totalTTC = 0;
  items.forEach(item => {
    const totalHT = item.quantity * item.unitPrice;
    const totalVATitem = item.vatRate === 0 ? 0 : (totalHT * item.vatRate / 100);
    subtotalHT += totalHT;
    totalVAT += totalVATitem;
    totalTTC += totalHT + totalVATitem;
  });
  subtotalHT = Math.max(0, subtotalHT - discount);
  totalTTC = Math.max(0, totalTTC - deposit);
  return {
    subtotalHT,
    totalVAT,
    totalTTC,
    discount,
    deposit,
    balance: totalTTC
  };
}

export default function InvoiceGenerator() {
  const [client, setClient] = useState({
    name: "",
    firstName: "",
    company: "",
    address: "",
    phone: "",
    email: "",
    nina: ""
  });
  const [items, setItems] = useState([ { ...emptyItem } ]);
  const [date, setDate] = useState(new Date().toISOString().slice(0,10));
  const [dueDate, setDueDate] = useState(new Date(Date.now() + 30*24*3600*1000).toISOString().slice(0,10));
  const [status, setStatus] = useState("brouillon");
  const [paymentTerms, setPaymentTerms] = useState("Paiement à 30 jours");
  const [notes, setNotes] = useState("");
  const [discount, setDiscount] = useState(0);
  const [deposit, setDeposit] = useState(0);

  const totals = calculateTotals(items, discount, deposit);

  function handleItemChange(idx, field, value) {
    setItems(items => items.map((item, i) => i === idx ? { ...item, [field]: value } : item));
  }

  function addItem() {
    setItems(items => [ ...items, { ...emptyItem } ]);
  }

  function removeItem(idx) {
    setItems(items => items.filter((_, i) => i !== idx));
  }

  function saveInvoice() {
    const invoice = {
      date,
      dueDate,
      status,
      client,
      items,
      totals,
      paymentTerms,
      notes
    };
    fetch("http://localhost:5000/api/invoices", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(invoice)
    })
    .then(r => r.json())
    .then(data => {
      alert("Facture créée : " + data.invoiceNumber);
      window.location.href = "/invoices";
    });
  }

  return (
    <div>
      <h2 className="text-xl font-bold mb-4 text-blue-700">Nouvelle Facture</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <form className="bg-white p-6 rounded shadow">
          <label className="block mb-2 font-medium">Date d’émission</label>
          <input type="date" value={date} onChange={e => setDate(e.target.value)} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Date d’échéance</label>
          <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Statut</label>
          <select value={status} onChange={e => setStatus(e.target.value)} className="mb-3 w-full border rounded px-2 py-1">
            <option value="brouillon">Brouillon</option>
            <option value="envoyée">Envoyée</option>
            <option value="payée">Payée</option>
            <option value="en retard">En retard</option>
          </select>
          <div className="font-bold mt-4 mb-2">Client</div>
          <input type="text" placeholder="Nom" value={client.name} onChange={e => setClient(c => ({ ...c, name: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <input type="text" placeholder="Prénom" value={client.firstName} onChange={e => setClient(c => ({ ...c, firstName: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <input type="text" placeholder="Entreprise (optionnel)" value={client.company} onChange={e => setClient(c => ({ ...c, company: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <input type="text" placeholder="Adresse complète" value={client.address} onChange={e => setClient(c => ({ ...c, address: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <input type="text" placeholder="Téléphone" value={client.phone} onChange={e => setClient(c => ({ ...c, phone: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <input type="email" placeholder="Email" value={client.email} onChange={e => setClient(c => ({ ...c, email: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <input type="text" placeholder="Numéro NINA (optionnel)" value={client.nina} onChange={e => setClient(c => ({ ...c, nina: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <div className="font-bold mt-4 mb-2">Articles / Services</div>
          {items.map((item, idx) => (
            <div key={idx} className="border p-2 rounded mb-2 bg-gray-50">
              <input type="text" placeholder="Description" value={item.description} onChange={e => handleItemChange(idx, "description", e.target.value)} className="mb-1 w-full border rounded px-2 py-1" />
              <input type="number" min={1} placeholder="Quantité" value={item.quantity} onChange={e => handleItemChange(idx, "quantity", +e.target.value)} className="mb-1 w-full border rounded px-2 py-1" />
              <input type="number" min={0} placeholder="Prix Unitaire HT" value={item.unitPrice} onChange={e => handleItemChange(idx, "unitPrice", +e.target.value)} className="mb-1 w-full border rounded px-2 py-1" />
              <select value={item.vatRate} onChange={e => handleItemChange(idx, "vatRate", +e.target.value)} className="mb-1 w-full border rounded px-2 py-1">
                <option value={0}>TVA 0%</option>
                <option value={18}>TVA 18%</option>
              </select>
              {items.length > 1 && (
                <button type="button" className="mt-1 text-red-600" onClick={() => removeItem(idx)}>Supprimer</button>
              )}
            </div>
          ))}
          <button type="button" className="mt-2 bg-blue-500 text-white px-3 py-1 rounded" onClick={addItem}>Ajouter un article</button>
          <div className="font-bold mt-4 mb-2">Conditions & Notes</div>
          <input type="text" placeholder="Conditions de paiement" value={paymentTerms} onChange={e => setPaymentTerms(e.target.value)} className="mb-2 w-full border rounded px-2 py-1" />
          <textarea placeholder="Notes" value={notes} onChange={e => setNotes(e.target.value)} className="mb-2 w-full border rounded px-2 py-1" />
          <div className="font-bold mt-4 mb-2">Remise (optionnelle)</div>
          <input type="number" min={0} value={discount} onChange={e => setDiscount(+e.target.value)} className="mb-2 w-full border rounded px-2 py-1" />
          <div className="font-bold mt-4 mb-2">Acompte versé (optionnel)</div>
          <input type="number" min={0} value={deposit} onChange={e => setDeposit(+e.target.value)} className="mb-2 w-full border rounded px-2 py-1" />
          <button type="button" className="mt-6 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700" onClick={saveInvoice}>Sauvegarder</button>
        </form>
        <InvoicePreview
          client={client}
          items={items}
          date={date}
          dueDate={dueDate}
          status={status}
          paymentTerms={paymentTerms}
          notes={notes}
          totals={totals}
        />
      </div>
    </div>
  );
}