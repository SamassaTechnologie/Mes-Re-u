import React from "react";
import { Link, useLocation } from "react-router-dom";
import logo from "../../public/logo.png";

const navLinks = [
  { path: "/", label: "Tableau de Bord" },
  { path: "/receipts", label: "Reçus" },
  { path: "/invoices", label: "Factures" },
];

export default function Navbar() {
  const location = useLocation();
  return (
    <nav className="flex items-center justify-between px-4 py-3 bg-white shadow">
      <div className="flex items-center gap-3">
        <img src={logo} alt="Logo Samassa" className="h-12 w-12" />
        <div>
          <div className="font-bold text-xl text-blue-600">SAMASSA TECHNOLOGIE</div>
          <div className="text-sm text-gray-700">Tout pour l’informatique</div>
        </div>
      </div>
      <div className="flex gap-6">
        {navLinks.map(link => (
          <Link
            key={link.path}
            to={link.path}
            className={`font-medium ${location.pathname === link.path ? "text-blue-600 underline" : "text-gray-800 hover:text-blue-500"}`}
          >
            {link.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}