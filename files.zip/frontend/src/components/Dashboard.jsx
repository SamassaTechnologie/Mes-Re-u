import React from "react";
import { Link } from "react-router-dom";

export default function Dashboard() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-4 text-blue-700">Tableau de Bord</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded shadow p-6">
          <div className="text-gray-500 mb-2">Reçus</div>
          <div className="text-3xl font-bold text-blue-600">--</div>
          <Link to="/create-receipt" className="mt-3 inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Nouveau Reçu</Link>
        </div>
        <div className="bg-white rounded shadow p-6">
          <div className="text-gray-500 mb-2">Factures</div>
          <div className="text-3xl font-bold text-blue-600">--</div>
          <Link to="/create-invoice" className="mt-3 inline-block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Nouvelle Facture</Link>
        </div>
        <div className="bg-white rounded shadow p-6">
          <div className="text-gray-500 mb-2">Chiffre d’Affaires</div>
          <div className="text-3xl font-bold text-blue-600">-- FCFA</div>
        </div>
      </div>
      <div className="bg-white rounded shadow p-6">
        <h3 className="text-lg font-semibold mb-2">Informations de l’Entreprise</h3>
        <ul className="text-gray-700">
          <li><b>Nom :</b> SAMASSA TECHNOLOGIE</li>
          <li><b>Adresse :</b> Grand Marché de Kayes, près du 1er Arrondissement de la Police</li>
          <li><b>Téléphones :</b> 77291931 / 62970630</li>
          <li><b>Email :</b> boussesamassa10@gmail.com</li>
        </ul>
      </div>
    </div>
  );
}