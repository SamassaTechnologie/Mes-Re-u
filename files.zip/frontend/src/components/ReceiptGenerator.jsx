import React, { useState } from "react";

export default function ReceiptGenerator() {
  const [form, setForm] = useState({
    number: "",
    date: new Date().toISOString().slice(0, 10),
    clientName: "",
    clientFirstName: "",
    clientNina: "",
    description: "",
    quantity: 1,
    unitPrice: 0,
    paymentMethod: "Cash"
  });
  const total = form.quantity * form.unitPrice;

  return (
    <div>
      <h2 className="text-xl font-bold mb-4 text-blue-700">Nouveau Reçu</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <form className="bg-white p-6 rounded shadow">
          <label className="block mb-2 font-medium">Numéro</label>
          <input type="text" value={form.number} onChange={e => setForm(f => ({ ...f, number: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Date</label>
          <input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Nom Client</label>
          <input type="text" value={form.clientName} onChange={e => setForm(f => ({ ...f, clientName: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Prénom</label>
          <input type="text" value={form.clientFirstName} onChange={e => setForm(f => ({ ...f, clientFirstName: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Numéro NINA (optionnel)</label>
          <input type="text" value={form.clientNina} onChange={e => setForm(f => ({ ...f, clientNina: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Description</label>
          <input type="text" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Quantité</label>
          <input type="number" min={1} value={form.quantity} onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Prix Unitaire</label>
          <input type="number" min={0} value={form.unitPrice} onChange={e => setForm(f => ({ ...f, unitPrice: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1" />
          <label className="block mb-2 font-medium">Mode de paiement</label>
          <select value={form.paymentMethod} onChange={e => setForm(f => ({ ...f, paymentMethod: e.target.value }))} className="mb-3 w-full border rounded px-2 py-1">
            <option>Cash</option>
            <option>Orange Money</option>
            <option>Chèque</option>
            <option>Virement</option>
          </select>
        </form>
        <div className="bg-white p-6 rounded shadow">
          <h3 className="font-bold mb-2">Aperçu du Reçu</h3>
          <div className="mb-1"><b>Numéro :</b> {form.number}</div>
          <div className="mb-1"><b>Date :</b> {form.date}</div>
          <div className="mb-1"><b>Client :</b> {form.clientName} {form.clientFirstName}</div>
          <div className="mb-1"><b>NINA :</b> {form.clientNina}</div>
          <div className="mb-1"><b>Description :</b> {form.description}</div>
          <div className="mb-1"><b>Quantité :</b> {form.quantity}</div>
          <div className="mb-1"><b>Prix Unitaire :</b> {form.unitPrice} FCFA</div>
          <div className="mb-1"><b>Mode paiement :</b> {form.paymentMethod}</div>
          <div className="mt-3 font-bold text-lg text-blue-700">Montant Total : {total} FCFA</div>
        </div>
      </div>
      <button className="mt-8 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Imprimer</button>
    </div>
  );
}