# SAMASSA TECHNOLOGIE - Frontend Netlify

## Déploiement sur Netlify

1. Uploadez ou connectez le dossier sur Netlify.
2. Commande de build : `npm run build`
3. Dossier de publication : `dist`
4. Ajoutez le fichier `_redirects` dans `/public` pour le routage.
5. Modifiez les URLs API pour pointer vers le backend Flask hébergé (Render, Railway, etc.)

## Backend

Netlify ne gère pas Flask. Hébergez le backend ailleurs et récupérez l’URL publique.

## Support

Contact : boussesamassa10@gmail.com  
Téléphones : 77291931 / 62970630